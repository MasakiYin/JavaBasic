package practice13.common;

public class Slime extends Character {
	public Slime() {
		super(10, 5, 2);
	}
}
