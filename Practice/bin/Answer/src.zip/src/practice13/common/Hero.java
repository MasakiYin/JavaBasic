package practice13.common;

public class Hero extends Character {
	public Hero() {
		super(25, 10, 7);
	}
}
