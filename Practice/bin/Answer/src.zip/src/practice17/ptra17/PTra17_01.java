/*
 * PTra17_01.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */
package practice17.ptra17;

import practice17.common.ThrowExceptionUtil;

public class PTra17_01 {
	public static void main(String[] args) {

		/*
		 * 以下のメソッドを呼び出すと例外が発生するため、例外処理を入れてください
		 * 	※例外発生時には、「例外が発生しました」を出力してください
		 */
		//ThrowExceptionUtil.nullToBlank(null);
		try {
			ThrowExceptionUtil.nullToBlank(null);
		} catch(NullPointerException e) {
			System.out.println("例外が発生しました");
		}
	}
}
