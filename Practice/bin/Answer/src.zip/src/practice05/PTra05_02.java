package practice05;
/*
 * PTra05_02.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra05_02 {
	public static void main(String[] args) {
		// 入力型プログラムです。
		// 下記の命令は、入力型プログラムで必要な記述になります。
		java.util.Scanner scanner = new java.util.Scanner(System.in);

		System.out.println("数値を入力してください");

		// コマンドプロンプトで入力した値が変数lineに代入されます
		String line = scanner.nextLine();

		// 変数inputを宣言して、変数lineを数値に変換した値を代入してください
		// ※ コマンドプロンプトで入力された値が、数字ではなかった場合はプログラムがエラーになって良いです
		int input = Integer.parseInt(line);

		/*
		 *  以下の仕様で、switch文を記述してください
		 *
		 *  ●変数inputが2で割り切れる場合		->	「##は偶数です」
		 *  ●変数inputが2で割り切れない場合	->	「##は奇数です」
		 *
		 *  ※##は変数inputの中身
		 */
		switch (input % 2) {
			case 0:
				System.out.println(input + "は偶数です");
				break;
			case 1:
				System.out.println(input + "は奇数です");
				break;
		}
	}
}
