package practice10;

public class User {
	int userId;
	String userNm;
	String mail;
	String password;
}
