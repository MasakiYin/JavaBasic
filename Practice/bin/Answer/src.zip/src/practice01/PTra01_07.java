package practice01;
/*
 * PTra01_07.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_07 {
	public static void main(String[] args) {

		// 基本型8種類の変数を宣言します
		boolean bo;
		byte by;
		short s;
		char c;
		int i;
		long l;
		float f;
		double d;

		// それぞれの型変数に、値を代入してください
		// ※ 値は、好きな数字を入力してください
		bo = true;
		by = 127;
		s = 32767;
		c = '教';
		i = 2147483647;
		l = 9223372036854775807L;
		f = 3.4028235F;
		d = 1.7976931348623157;

		// それぞれの変数の中身を出力してください
		System.out.println(bo);
		System.out.println(by);
		System.out.println(s);
		System.out.println(c);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);

	}
}
