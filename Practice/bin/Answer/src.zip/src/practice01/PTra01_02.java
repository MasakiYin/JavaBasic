package practice01;
/*
 * PTra01_02.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_02 {
	public static void main(String[] args) {

		// 12～14行目をコメントにしてください。
		/*
		ここをコメントにしてください
		ここをコメントにしてください
		ここをコメントにしてください
		*/

		// 「Hello, world」と出力（コマンドプロンプトに表示）してください
		System.out.println("Hello, world");


	}
}
