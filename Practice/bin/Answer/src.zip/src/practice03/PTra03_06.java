package practice03;
/*
 * PTra03_06.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra03_06 {
	public static void main(String[] args) {
		int limitNumber = 100;

		// ランダムで数字を生成するプログラムです。
		// 下記の命令を実行すると変数randomに、0以上、変数limitNumber未満の数字がランダムで代入されます
		int random = new java.util.Random().nextInt(limitNumber + 1);

		//---------------------ここから本題-----------------------
		/*
		 * 以下の仕様に沿ってプログラムを完成させてください
		 *
		 * ●変数randomの値から、出力する値を変更します。
		 * ● 100~71の場合		->	「☆☆☆☆☆」
		 * ● 70~31の場合		->	「☆☆☆☆」
		 * ● 上記以外の場合	->	「☆☆☆」
		 *
		 * ※ プログラムは何行書いても良いです
		 */

		// 100~71の時
		if (random <= 100 && random > 30) {
			System.out.println("☆☆☆☆☆");
		} else if (random <= 70 && random > 31) {
			// 70~31
			System.out.println("☆☆☆☆");
		} else {
			// 上の条件にかからなければ・・・
			System.out.println("☆☆☆");
		}
	}
}
