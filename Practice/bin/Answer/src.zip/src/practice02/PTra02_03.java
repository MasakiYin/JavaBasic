package practice02;
/*
 * PTra02_03.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_03 {
	public static void main(String[] args) {
		int num1 = 50;
		System.out.println(num1);

		// プログラムを修正して、num2に120が入るようにしてください
		//int num2 = 20 + num1 + num1;
		int num2 = 20 + (num1 + num1);

		// 以下のプログラムで120が出力されるようにしてください
		System.out.println(num2);	// ※※ この行は修正しないでください
	}
}
