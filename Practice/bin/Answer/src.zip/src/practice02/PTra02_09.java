package practice02;
/*
 * PTra02_09.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra02_09 {
	public static void main(String[] args) {
		int length = 9;	// 底辺
		int height = 23;	// 高さ

		// 変数quadrangleに、四角形の面積を代入してください
		double quadrangle = (double)length * height;		// doubleでキャストする必要はけれど・・・

		// 変数quadrangleを出力してください
		System.out.println("四角形の面積：" + quadrangle);

		// 変数triangleに、三角形の面積を代入してください
		double triangle = (double)length * height / 2;	// int同士の計算だと結果がintになってしまうのでキャスト

		// 変数triangleを出力してください
		System.out.println("三角形の面積：" + triangle);

	}
}
